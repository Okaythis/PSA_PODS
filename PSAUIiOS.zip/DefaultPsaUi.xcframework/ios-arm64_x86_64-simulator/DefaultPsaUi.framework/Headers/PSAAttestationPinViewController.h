//
//  PSAAttestationPinViewController.h
//  DefaultPsaUi
//
//  Created by Satheesh Kannan on 16/02/23.
//  Copyright © 2023 Protectoria. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <PSACommon/PSACommon.h>

NS_ASSUME_NONNULL_BEGIN

#define PSA_ATTESTATION_MIN_PIN_LIMIT  2
#define PSA_ATTESTATION_MAX_PIN_LIMIT  15

@protocol PSAAttestationPinDelegate <NSObject>

- (void)submittedPIN: (NSString *)pin;
- (void)userForgotPIN;
- (void)userCancelledPINFlow;

@end

@interface PSAAttestationPinViewController : UIViewController

+ (instancetype)controllerWithDelegate: (id<PSAAttestationPinDelegate>)delegate andTheme:(PSAPINLoginTheme *) theme;

- (void)resetScreen;
- (void)showErrorMessage:(NSString *)message;

@end

NS_ASSUME_NONNULL_END
