// Copyright © Protectoria. All rights reserved.

#import <UIKit/UIKit.h>

//! Project version number for PSA.
FOUNDATION_EXPORT double PSAVersionNumber;

//! Project version string for PSA.
FOUNDATION_EXPORT const unsigned char PSAVersionString[];

// In this header, you should import all the public headers of your framework using statements like
#import <PSA/PSAPublic.h>
#import <PSA/PSATenant.h>
#import <PSA/TransactionInfo.h>
#import <PSA/PSANotificationData.h>
#import <PSA/PSAPINLoginCustomErrorMessages.h>
#import <DefaultPsaUi/DefaultPsaUi.h>
