//
//  PSANotificationData.h
//  PSA
//
//  Created by SK on 02/06/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSANotificationData : NSObject

@property NSNumber *sessionId;
@property NSNumber *tenantId;
@property NSString *sessionExternalId;
@property NSString *clientServerUrl;
@property NSNumber *isDisableMultipleRetry;
@property NSString *userExternalID;

@end

NS_ASSUME_NONNULL_END
