//
//  Watermarker.h
//  Watermarker
//
//  Created by Borovik, Edgar2 on 9/28/20.
//  Copyright © 2020 Protectoria. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Watermarker.
FOUNDATION_EXPORT double WatermarkerVersionNumber;

//! Project version string for Watermarker.
FOUNDATION_EXPORT const unsigned char WatermarkerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Watermarker/PublicHeader.h>


