// Copyright © Protectoria. All rights reserved.

#import <Foundation/Foundation.h>
#import <PSACommon/PSASharedStatuses.h>

@interface PSAErrorParser : NSObject

- (PSASharedStatuses)parseErrorCode:(NSInteger)errorCode;

@end
