//
//  PSAKeyChainStorage.h
//  PSACommon
//
//  Created by Satheesh Kannan on 31/01/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const kPSAKeyChainStorageKeyPubSecret;

@interface PSAKeyChainStorage : NSObject

+ (PSAKeyChainStorage *)sharedManger;

-(BOOL)storeData:(NSData *)data forKey:(NSString *)key;
-(BOOL)updateData:(NSData *)data forKey:(NSString *)key;

-(NSData *)collectDataForKey:(NSString *)key;
-(BOOL) removeDataForKey:(NSString *)key;

+ (void)savePubSecret:(NSString *) pubSecret;
+ (nullable NSString *)retrivePubSecret;

@end

NS_ASSUME_NONNULL_END
