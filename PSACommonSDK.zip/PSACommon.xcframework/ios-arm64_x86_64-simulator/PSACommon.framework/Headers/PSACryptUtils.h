// Copyright © Protectoria. All rights reserved.

#import <Foundation/Foundation.h>
#import <PSACommon/PSACryptUtilsB64.h>
#import <PSACommon/PSACryptUtilsAsymmetric.h>
#import <PSACommon/PSACryptUtilsSymmetric.h>
#import <PSACommon/PSACryptUtilsMD5.h>
#import <PSACommon/PSACryptUtilsSHA256.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSACryptUtils : NSObject

+ (nullable NSData *)generateNonce;

+ (nullable NSData *)generateNonce:(nullable NSString *)seed data:(nullable NSData *)data;

+ (void)logCryptoPPException:(const char *)exceptionUTF8String;

@end

NS_ASSUME_NONNULL_END
