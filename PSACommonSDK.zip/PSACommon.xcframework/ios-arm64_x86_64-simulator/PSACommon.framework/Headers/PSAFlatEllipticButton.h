// Copyright © Protectoria. All rights reserved.

#import <UIKit/UIKit.h>
#import <PSACommon/PSARoundButton.h>

@interface PSAFlatEllipticButton : PSARoundButton

@end
